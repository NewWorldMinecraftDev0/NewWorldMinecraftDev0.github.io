[core]
Core assets